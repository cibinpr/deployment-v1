// ===========================================================================
//  Class Valuation "Bluebird" auto-accept bot  --  configuration
//  Put your credentials here. Nothing else in the project needs editing.
// ===========================================================================

module.exports = {

  // ---- client / account -------------------------------------------------
  clientName: 'darryl',                 // used in the log file name
  username: '499372',
  password: 'Powerhouse1@',

  // ---- portal -----------------------------------------------------------
  baseUrl: 'https://cmp-vendors.classvaluation.com',
  loginPath: '/Account/Login',
  dashboardPath: '/Orders/Dashboard',

  // Login page. The checkbox and button ids are confirmed. The Vendor ID
  // box is auto-detected (first visible text input on the form) - if you
  // know its id, put it here and it will be used instead.
  loginSelectors: {
    username: '',                        // '' = auto-detect, or e.g. '#VendorID'
    password: 'input[type="password"]',
    checkbox: '#checkAcceptLoginTnC',    // must be ticked or Login stays disabled
    submit: '#submitLogin'
  },

  // ---- speed ------------------------------------------------------------
  reloadEveryMs: 3000,      // how often the New Orders grid is refreshed
  scanEveryMs: 250,         // how often Node reads the grid rows
  modalTimeoutMs: 8000,     // max wait for the accept popup
  resultTimeoutMs: 15000,   // max wait for the OK popup after submitting

  // ---- session ----------------------------------------------------------
  recycleMinutes: 20,       // kill Chrome + log in again this often
  headless: false,          // true = no visible window (faster, less RAM)

  // ---- filters ----------------------------------------------------------
  // Leave acceptAll true to take every new order. Set it false to use the
  // three filters below.
  acceptAll: true,
  zipWhitelist: [],         // e.g. ['341', '34117', '331'] - startsWith match
  minFee: 0,                // e.g. 30  -> skip anything under $30
  productRules: [],         // e.g. [{ match: 'PCR', minFee: 30 },
                            //       { match: 'Ext', minFee: 40 }]

  // ---- logging ----------------------------------------------------------
  logFile: 'accepted-orders.log',
  logSkipped: true          // also record orders that were filtered out
};
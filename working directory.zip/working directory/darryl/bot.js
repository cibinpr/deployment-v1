// ===========================================================================
//  Class Valuation "Bluebird" auto-accept bot
//
//  Flow (all ids/selectors confirmed against the portal's page source):
//    1. #gridNewOrders  ->  row appears
//    2. acceptOrder(orderKey)          opens #acceptOrderModal
//    3. #checkAcceptOrderTnC           real click, enables the button
//    4. #btnAcceptOrderSubmit          POSTs /Orders/{id}/Items/{item}/Accept
//    5. #resultModal                   #failList empty  = order is ours
//    6. #resultModal .modal-footer button   -> OK, back to New Orders
// ===========================================================================

const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const os = require('os');
const { Builder, By, until } = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');

const cfg = require('./config');

// ---------------------------------------------------------------------------
//  timestamps  --  IST + US Eastern, the way the other bots log them
// ---------------------------------------------------------------------------
function stamp(tz) {
  return new Intl.DateTimeFormat('en-US', {
    timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
  }).format(new Date());
}
const ist = () => stamp('Asia/Kolkata');
const est = () => stamp('America/New_York');

const LOG_PATH = path.join(__dirname, cfg.logFile);

function say(msg) {
  console.log(`[${ist()} IST] ${msg}`);
}

function writeLog(kind, order, extra) {
  const lines = [
    '========================================================================',
    `${kind}`,
    `Client        : ${cfg.clientName}`,
    `Time (IST)    : ${ist()}`,
    `Time (US/East): ${est()}`,
    '------------------------------------------------------------------------',
    `Order Key     : ${order.OrderKey || ''}`,
    `Order ID      : ${order.OrderID || ''}`,
    `Order Item ID : ${order.OrderItemID || ''}`,
    `Product       : ${order.VendorProduct || order.Product || ''}`,
    `Product Type  : ${order.ProductTypeID || ''}`,
    `Fee           : ${order.AdjustedFee || ''}`,
    `Vendor Fee    : ${order.VendorFee || ''}`,
    `Tech Fee      : ${order.VendorTechFee || ''}`,
    `Address       : ${order.SubjectPropertyAddress1 || ''} ${order.SubjectPropertyAddress2 || ''}`.trim(),
    `City/State/Zip: ${order.SubjectPropertyCity || ''}, ${order.SubjectPropertyState || ''} ${order.SubjectPropertyPostalCode || ''}`,
    `Lat / Long    : ${order.Latitude || ''} , ${order.Longitude || ''}`,
    `Borrower      : ${order.Borrower || ''}`,
    `Client        : ${order.Client || ''}`,
    `Client Alt    : ${order.ClientCalculatedAlternativeName || ''}`,
    `Client Addr   : ${order.RecipientAddress1 || ''}, ${order.RecipientCity || ''}, ${order.RecipientState || ''} ${order.RecipientPostalCode || ''}`,
    `AMC           : ${order.AMCName || ''}`,
    `Loan Number   : ${order.LoanNumber || ''}`,
    `Loan Purpose  : ${order.LoanPurposeDescription || ''}`,
    `Loan Type     : ${order.LoanTypeDescription || ''}`,
    `FHA Case No   : ${order.FHACaseNumber || ''}`,
    `Assigned Date : ${order.AssignedDate || ''}`,
    `Due Date      : ${order.DueDate || ''}`,
    `Queue         : ${order.Queue || ''}`,
    `Rush          : ${order.RushOrder || ''}`,
    `On Hold       : ${order.OnHold || ''}`,
    `Appt Required : ${order.AppointmentRequired || ''}`,
    `Overdue       : ${order.Overdue || ''}`
  ];
  if (extra) lines.push('------------------------------------------------------------------------', extra);
  lines.push('========================================================================', '');
  fs.appendFileSync(LOG_PATH, lines.join('\n'), 'utf8');
}

// ---------------------------------------------------------------------------
//  page-side helpers  --  injected once per session
// ---------------------------------------------------------------------------
const PAGE_HELPERS = `
window.__bb = {
  // read every row of the New Orders grid with all its hidden columns
  scan: function () {
    var out = [];
    document.querySelectorAll('#gridNewOrders tr.jqgrow').forEach(function (tr) {
      var o = {};
      tr.querySelectorAll('td[aria-describedby]').forEach(function (td) {
        var k = td.getAttribute('aria-describedby')
                  .replace('gridNewOrders_OrderInfo.', '')
                  .replace('gridNewOrders_', '');
        o[k] = (td.innerText || '').trim();
      });
      if (o.OrderKey) out.push(o);
    });
    return out;
  },

  reload: function () {
    try { jQuery('#gridNewOrders').trigger('reloadGrid'); } catch (e) {}
  },

  newOrdersTab: function () {
    try {
      if (!jQuery('#NewOrdersTab').hasClass('active')) {
        jQuery('#NewOrdersTab a').tab('show');
      }
    } catch (e) {}
  },

  // step 2 - open the accept popup
  open: function (orderKey) {
    try { acceptOrder(orderKey); return 'ok'; }
    catch (e) { return 'ERR ' + e; }
  },

  modalOpen: function () {
    var m = document.getElementById('acceptOrderModal');
    return !!(m && m.offsetParent !== null &&
              document.getElementById('OrderID').value !== '0');
  },

  // steps 3 + 4 - tick T&C with a REAL click, then submit
  submit: function () {
    var cb = document.getElementById('checkAcceptOrderTnC');
    if (!cb) return 'no-checkbox';
    if (!cb.checked) cb.click();
    var cond = document.getElementById('IsConditionalAcceptance');
    if (cond && cond.checked) cond.click();   // never counter-offer
    var btn = document.getElementById('btnAcceptOrderSubmit');
    if (!btn) return 'no-button';
    if (btn.disabled) return 'still-disabled';
    btn.click();
    return 'submitted';
  },

  // step 5 - read the OK popup
  result: function () {
    var m = document.getElementById('resultModal');
    if (!m || m.offsetParent === null) return null;
    var fails = [].map.call(m.querySelectorAll('#failList li'),
                            function (li) { return (li.innerText || '').trim(); });
    var st = document.getElementById('successText');
    return {
      ok: fails.length === 0,
      message: st ? (st.innerText || '').trim() : '',
      errors: fails
    };
  },

  // step 6 - OK, and clear anything left behind
  dismiss: function () {
    var b = document.querySelector('#resultModal .modal-footer button');
    if (b) b.click();
    try {
      jQuery('#resultModal').modal('hide');
      jQuery('#acceptOrderModal').modal('hide');
      jQuery('.modal-backdrop').remove();
      jQuery('body').removeClass('modal-open');
    } catch (e) {}
    return true;
  },

  loggedIn: function () {
    return !!document.getElementById('gridNewOrders');
  }
};
`;

// ---------------------------------------------------------------------------
//  filters
// ---------------------------------------------------------------------------
function feeOf(order) {
  const n = parseFloat(String(order.AdjustedFee || order.VendorFee || '').replace(/[^0-9.]/g, ''));
  return isNaN(n) ? 0 : n;
}

function shouldAccept(order) {
  if (String(order.OnHold).toLowerCase() === 'true') return { ok: false, why: 'order is ON HOLD' };
  if (cfg.acceptAll) return { ok: true };

  const zip = String(order.SubjectPropertyPostalCode || '');
  if (cfg.zipWhitelist.length && !cfg.zipWhitelist.some(z => zip.startsWith(z)))
    return { ok: false, why: `zip ${zip} not in whitelist` };

  const fee = feeOf(order);
  if (cfg.minFee && fee < cfg.minFee)
    return { ok: false, why: `fee $${fee} below minimum $${cfg.minFee}` };

  if (cfg.productRules.length) {
    const prod = String(order.VendorProduct || order.Product || '');
    const rule = cfg.productRules.find(r => prod.toUpperCase().includes(r.match.toUpperCase()));
    if (!rule) return { ok: false, why: `product "${prod}" matches no rule` };
    if (fee < rule.minFee)
      return { ok: false, why: `fee $${fee} below $${rule.minFee} for ${rule.match}` };
  }
  return { ok: true };
}

// ---------------------------------------------------------------------------
//  Chrome lifecycle  --  our window only, never anyone else's
// ---------------------------------------------------------------------------
const PROFILE_DIR = path.join(os.tmpdir(), `bluebird-${cfg.clientName}-${process.pid}`);

function killOurChromeOnly() {
  // Every Chrome we start uses PROFILE_DIR, which contains this process's PID.
  // Matching on it means a manually-opened Chrome is never touched.
  return new Promise(resolve => {
    if (process.platform !== 'win32') return resolve();
    const ps = `Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" | ` +
               `Where-Object { $_.CommandLine -like '*${PROFILE_DIR.replace(/\\/g, '\\\\')}*' } | ` +
               `ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }`;
    execFile('powershell.exe', ['-NoProfile', '-Command', ps], () => resolve());
  });
}

async function startBrowser() {
  const opts = new chrome.Options();
  opts.addArguments(
    `--user-data-dir=${PROFILE_DIR}`,   // <-- our fingerprint for the kill step
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-notifications',
    '--disable-popup-blocking',
    '--window-size=1400,900'
  );
  if (cfg.headless) opts.addArguments('--headless=new');

  const driver = await new Builder()
    .forBrowser('chrome')
    .setChromeOptions(opts)
    .build();

  await driver.manage().setTimeouts({ pageLoad: 60000, script: 30000 });
  return driver;
}

// The whole login happens in one injected call - fill both boxes, tick
// #checkAcceptLoginTnC (a real click, it is what un-disables the button),
// then click #submitLogin. No per-keystroke round trips to the browser.
const FAST_LOGIN = `
var user = arguments[0], pass = arguments[1], sel = arguments[2];

function setValue(el, v) {
  el.focus();
  var setter = Object.getOwnPropertyDescriptor(
                 window.HTMLInputElement.prototype, 'value').set;
  setter.call(el, v);
  ['input', 'keyup', 'change', 'blur'].forEach(function (t) {
    el.dispatchEvent(new Event(t, { bubbles: true }));
  });
}

var pwd = document.querySelector(sel.password) ||
          document.querySelector('input[type="password"]');
if (!pwd) return 'no-password-field';

var scope = pwd.form || document;
var uid = sel.username ? document.querySelector(sel.username) : null;
if (!uid) {
  uid = Array.prototype.filter.call(scope.querySelectorAll('input'), function (i) {
    return (i.type === 'text' || i.type === '') && i.offsetParent !== null;
  })[0];
}
if (!uid) return 'no-vendorid-field';

setValue(uid, user);
setValue(pwd, pass);

var cb = document.querySelector(sel.checkbox);
if (cb && !cb.checked) cb.click();          // real click - enables the button

var btn = document.querySelector(sel.submit);
if (!btn) return 'no-login-button';
if (btn.disabled) return 'login-button-still-disabled';
btn.click();
return 'submitted';
`;

async function login(driver) {
  const t0 = Date.now();
  say('logging in...');

  await driver.get(cfg.baseUrl + cfg.loginPath);
  await driver.wait(
    until.elementLocated(By.css(cfg.loginSelectors.password)), 30000);

  const state = await driver.executeScript(
    FAST_LOGIN, cfg.username, cfg.password, cfg.loginSelectors);
  if (state !== 'submitted') throw new Error(`login failed: ${state}`);

  await driver.wait(until.elementLocated(By.id('gridNewOrders')), 45000);
  await driver.executeScript(PAGE_HELPERS);
  await driver.executeScript('window.__bb.newOrdersTab();');

  say(`logged in in ${((Date.now() - t0) / 1000).toFixed(2)}s - watching New Orders`);
}

// ---------------------------------------------------------------------------
//  the accept sequence  --  target is well under 3 seconds
// ---------------------------------------------------------------------------
async function acceptOrder(driver, order) {
  const t0 = Date.now();
  const key = order.OrderKey;

  const opened = await driver.executeScript('return window.__bb.open(arguments[0]);', key);
  if (opened !== 'ok') throw new Error(`could not open popup: ${opened}`);

  await driver.wait(async () =>
    driver.executeScript('return window.__bb.modalOpen();'), cfg.modalTimeoutMs);

  let state = '';
  const deadline = Date.now() + cfg.modalTimeoutMs;
  while (Date.now() < deadline) {
    state = await driver.executeScript('return window.__bb.submit();');
    if (state === 'submitted') break;
    await driver.sleep(100);          // button enables the moment T&C is ticked
  }
  if (state !== 'submitted') throw new Error(`could not submit: ${state}`);

  let result = null;
  const rDeadline = Date.now() + cfg.resultTimeoutMs;
  while (Date.now() < rDeadline) {
    result = await driver.executeScript('return window.__bb.result();');
    if (result) break;
    await driver.sleep(150);
  }

  const secs = ((Date.now() - t0) / 1000).toFixed(2);

  if (!result) {
    await driver.executeScript('return window.__bb.dismiss();');
    throw new Error(`no result popup after ${secs}s`);
  }

  await driver.executeScript('return window.__bb.dismiss();');
  await driver.executeScript('window.__bb.newOrdersTab();');

  return { ok: result.ok, message: result.message, errors: result.errors, secs };
}

// ---------------------------------------------------------------------------
//  one session  --  runs until the recycle timer expires
// ---------------------------------------------------------------------------
async function runSession() {
  const driver = await startBrowser();
  const endAt = Date.now() + cfg.recycleMinutes * 60 * 1000;
  const handled = new Map();        // orderKey -> time last attempted

  try {
    await login(driver);
    let lastReload = 0;

    while (Date.now() < endAt) {
      if (Date.now() - lastReload >= cfg.reloadEveryMs) {
        await driver.executeScript('window.__bb.reload();');
        lastReload = Date.now();
      }

      let rows = [];
      try {
        rows = await driver.executeScript('return window.__bb.scan();') || [];
      } catch (e) {
        // page navigated or session dropped - let the outer loop recycle
        const alive = await driver.executeScript('return window.__bb && window.__bb.loggedIn();')
          .catch(() => false);
        if (!alive) throw new Error('page lost - recycling');
      }

      for (const order of rows) {
        const key = order.OrderKey;
        if (handled.has(key) && Date.now() - handled.get(key) < 60000) continue;

        const verdict = shouldAccept(order);
        if (!verdict.ok) {
          if (!handled.has(key)) {
            say(`SKIP ${key} - ${verdict.why}`);
            if (cfg.logSkipped) writeLog('SKIPPED', order, `Reason: ${verdict.why}`);
          }
          handled.set(key, Date.now());
          continue;
        }

        say(`NEW ORDER ${key} - ${order.SubjectPropertyCity}, ${order.SubjectPropertyState} ` +
            `${order.SubjectPropertyPostalCode} - ${order.AdjustedFee} - accepting...`);
        handled.set(key, Date.now());

        try {
          const r = await acceptOrder(driver, order);
          if (r.ok) {
            say(`ACCEPTED ${key} in ${r.secs}s`);
            writeLog('ACCEPTED', order,
              `Accept took : ${r.secs} seconds\nServer says : ${r.message}`);
          } else {
            say(`MISSED ${key} in ${r.secs}s - ${r.errors.join(' | ')}`);
            writeLog('FAILED', order,
              `Accept took : ${r.secs} seconds\nServer says : ${r.errors.join(' | ')}`);
          }
        } catch (e) {
          say(`ERROR on ${key} - ${e.message}`);
          writeLog('ERROR', order, `Error: ${e.message}`);
          await driver.executeScript('return window.__bb.dismiss();').catch(() => {});
        }
      }

      await driver.sleep(cfg.scanEveryMs);
    }

    say(`${cfg.recycleMinutes} minutes up - recycling session`);
  } finally {
    await driver.quit().catch(() => {});
    await killOurChromeOnly();
  }
}

// ---------------------------------------------------------------------------
//  main  --  keep recycling forever
// ---------------------------------------------------------------------------
(async () => {
  say(`Bluebird bot starting for "${cfg.clientName}"`);
  say(`profile dir: ${PROFILE_DIR}`);
  say(`log file   : ${LOG_PATH}`);

  process.on('SIGINT', async () => {
    say('stopping...');
    await killOurChromeOnly();
    process.exit(0);
  });

  for (;;) {
    try {
      await runSession();
    } catch (e) {
      say(`session ended: ${e.message}`);
      await killOurChromeOnly();
      await new Promise(r => setTimeout(r, 5000));
    }
  }
})();